<?php
/**
 * CMS Platform - Auth Controller
 * متحكم المصادقة
 */

class AuthController extends Controller
{
    private $userModel;

    public function __construct()
    {
        parent::__construct();
        $this->userModel = $this->model('User');
    }

    /**
     * عرض صفحة تسجيل الدخول
     */
    public function login()
    {
        // إذا كان مسجل دخوله مسبقاً
        if (Auth::check()) {
            if (Auth::isAdmin()) {
                $this->redirect('/admin');
            }
            $this->redirect('/dashboard');
        }

        $this->view('auth/login', [
            'title' => 'تسجيل الدخول'
        ]);
    }

    /**
     * معالجة تسجيل الدخول
     */
    public function doLogin()
    {
        $this->verifyCsrf();

        if (!Security::rateLimit('login_' . Security::getClientIp(), 5, 1)) {
            Session::error('تم تجاوز الحد الأقصى للمحاولات. يرجى المحاولة بعد دقيقة');
            $this->redirect('/login');
        }

        $email = $this->input('email');
        $password = $this->input('password');
        $remember = $this->input('remember') === 'on';

        // التحقق من البيانات
        $errors = $this->validate($_POST, [
            'email' => ['required', 'email'],
            'password' => ['required']
        ]);

        if (!empty($errors)) {
            Session::error(array_values($errors)[0]);
            $this->back();
        }

        // محاولة تسجيل الدخول
        if (Auth::attempt($email, $password, $remember)) {
            Session::success('تم تسجيل الدخول بنجاح');
            
            // توجيه حسب الدور
            if (Auth::isAdmin()) {
                $this->redirect('/admin');
            } else {
                $this->redirect('/dashboard');
            }
        }

        Session::error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
        $this->back();
    }

    /**
     * عرض صفحة التسجيل
     */
    public function register()
    {
        if (Auth::check()) {
            if (Auth::isAdmin()) {
                $this->redirect('/admin');
            }
            $this->redirect('/dashboard');
        }

        $this->view('auth/register', [
            'title' => 'إنشاء حساب جديد'
        ]);
    }

    /**
     * معالجة التسجيل
     */
    public function doRegister()
    {
        $this->verifyCsrf();

        $data = [
            'full_name' => $this->input('full_name'),
            'email' => $this->input('email'),
            'phone' => $this->input('phone'),
            'password' => $this->input('password'),
            'confirm_password' => $this->input('confirm_password')
        ];

        // التحقق من البيانات
        $errors = $this->validate($data, [
            'full_name' => ['required', 'min:3'],
            'email' => ['required', 'email'],
            'phone' => ['required'],
            'password' => ['required', 'min:8'],
            'confirm_password' => ['required', 'match:password']
        ]);

        if (!empty($errors)) {
            Session::error(array_values($errors)[0]);
            $this->back();
        }

        // التحقق من وجود البريد
        if ($this->userModel->emailExists($data['email'])) {
            Session::error('البريد الإلكتروني مسجل مسبقاً');
            $this->back();
        }

        // إنشاء المستخدم
        $userId = $this->userModel->register([
            'full_name' => $data['full_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => $data['password'],
            'status' => 'active',
            'email_verified' => 1 // يمكن تعديله لاحقاً لإضافة التحقق
        ]);

        if ($userId) {
            // تسجيل الدخول تلقائياً
            $user = $this->userModel->find($userId);
            Auth::login($user);

            Session::success('تم إنشاء الحساب بنجاح');
            $this->redirect('/site/create');
        }

        Session::error('حدث خطأ أثناء إنشاء الحساب');
        $this->back();
    }

    /**
     * تسجيل الخروج
     */
    public function logout()
    {
        Auth::logout();
        Session::success('تم تسجيل الخروج بنجاح');
        $this->redirect('/');
    }

    /**
     * عرض صفحة نسيت كلمة المرور
     */
    public function forgotPassword()
    {
        $this->view('auth/forgot-password', [
            'title' => 'استعادة كلمة المرور'
        ]);
    }

    /**
     * إرسال رابط استعادة كلمة المرور
     */
    public function sendResetLink()
    {
        $this->verifyCsrf();

        $email = $this->input('email');

        if (!$email) {
            Session::error('يرجى إدخال البريد الإلكتروني');
            $this->back();
        }

        $token = $this->userModel->createResetToken($email);

        if ($token) {
            // هنا يمكن إرسال البريد الإلكتروني
            // sendMail($email, 'استعادة كلمة المرور', "رابط الاستعادة: .../{$token}");
            
            Session::success('تم إرسال رابط الاستعادة إلى بريدك الإلكتروني');
        } else {
            Session::error('البريد الإلكتروني غير مسجل');
        }

        $this->redirect('/login');
    }

    /**
     * عرض صفحة إعادة تعيين كلمة المرور
     */
    public function resetPassword($token)
    {
        $user = $this->userModel->verifyResetToken($token);

        if (!$user) {
            Session::error('رابط الاستعادة غير صالح أو منتهي الصلاحية');
            $this->redirect('/login');
        }

        $this->view('auth/reset-password', [
            'title' => 'إعادة تعيين كلمة المرور',
            'token' => $token
        ]);
    }

    /**
     * تحديث كلمة المرور
     */
    public function updatePassword()
    {
        $this->verifyCsrf();

        $token = $this->input('token');
        $password = $this->input('password');
        $confirmPassword = $this->input('confirm_password');

        if ($password !== $confirmPassword) {
            Session::error('كلمتا المرور غير متطابقتين');
            $this->back();
        }

        if (strlen($password) < 6) {
            Session::error('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
            $this->back();
        }

        if ($this->userModel->resetPassword($token, $password)) {
            Session::success('تم تحديث كلمة المرور بنجاح');
            $this->redirect('/login');
        }

        Session::error('حدث خطأ أثناء تحديث كلمة المرور');
        $this->back();
    }
}
