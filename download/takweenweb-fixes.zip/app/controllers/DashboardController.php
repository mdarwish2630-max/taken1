<?php
/**
 * CMS Platform - Dashboard Controller
 * متحكم لوحة التحكم
 */

class DashboardController extends Controller
{
    private $tenantModel;
    private $pageModel;
    private $serviceModel;
    private $bannerModel;
    private $galleryModel;
    private $testimonialModel;
    private $demoDataModel;

    public function __construct()
    {
        parent::__construct();
        // منع المدير من الوصول للوحة تحكم العميل
        if (Auth::isAdmin()) {
            Session::error('هذه الصفحة متاحة للعملاء فقط');
            $this->redirect('/admin');
        }
        $this->requireAuth();
        
        $this->tenantModel = $this->model('Tenant');
        $this->pageModel = $this->model('Page');
        $this->serviceModel = $this->model('Service');
        $this->bannerModel = $this->model('Banner');
        $this->galleryModel = $this->model('Gallery');
        $this->testimonialModel = $this->model('Testimonial');
        $this->demoDataModel = $this->model('DemoData');
    }

    /**
     * عرض لوحة التحكم الرئيسية
     */
    public function index()
    {
        $tenant = Auth::tenant();

        if (!$tenant) {
            // إذا لم يكن لديه موقع، توجيه لإنشاء موقع
            $this->redirect('/site/create');
        }

        $stats = $this->tenantModel->getStats($tenant->id);

        $this->view('dashboard/index', [
            'title' => 'لوحة التحكم',
            'tenant' => $tenant,
            'stats' => $stats,
            'recent_messages' => $this->getRecentMessages($tenant->id)
        ]);
    }

    /**
     * الحصول على الرسائل الأخيرة
     */
    private function getRecentMessages($tenantId, $limit = 5)
    {
        $db = Database::getInstance();
        return $db->query(
            "SELECT * FROM contact_messages WHERE tenant_id = ? ORDER BY created_at DESC LIMIT ?",
            [$tenantId, $limit]
        )->results();
    }

    /**
     * عرض صفحة الإعدادات
     */
    public function settings()
    {
        $tenant = Auth::tenant();
        $themeModel = $this->model('Theme');
        $themes = $themeModel->getActive();
        
        // الحصول على إعدادات الأقسام
        $sectionsConfig = $this->tenantModel->getSectionsConfig($tenant->id);

        $this->view('dashboard/settings', [
            'title' => 'إعدادات الموقع',
            'tenant' => $tenant,
            'themes' => $themes,
            'sectionsConfig' => $sectionsConfig
        ]);
    }

    /**
     * تحديث إعدادات الموقع
     */
    public function updateSettings()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $tenantId = $tenant->id;

        // تحديث معلومات أساسية
        $basicData = [
            'site_name' => $this->input('site_name'),
            'contact_email' => $this->input('contact_email'),
            'contact_phone' => $this->input('contact_phone'),
            'contact_phone2' => $this->input('contact_phone2'),
            'contact_whatsapp' => $this->input('contact_whatsapp'),
            'address' => $this->input('address'),
            'working_hours' => $this->input('working_hours'),
        ];

        $this->tenantModel->update($tenantId, $basicData);

        // تحديث السوشال ميديا
        $socialData = [
            'facebook' => $this->input('facebook'),
            'twitter' => $this->input('twitter'),
            'instagram' => $this->input('instagram'),
            'linkedin' => $this->input('linkedin'),
            'youtube' => $this->input('youtube'),
            'tiktok' => $this->input('tiktok'),
        ];

        $this->tenantModel->updateSocial($tenantId, $socialData);

        // تحديث SEO
        $seoData = [
            'meta_title' => $this->input('meta_title'),
            'meta_description' => $this->input('meta_description'),
            'meta_keywords' => $this->input('meta_keywords'),
        ];

        $this->tenantModel->updateSeo($tenantId, $seoData);

        Session::success('تم حفظ الإعدادات بنجاح');
        $this->redirect('/dashboard/settings');
    }

    /**
     * تحديث الألوان
     */
    public function updateColors()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        $colors = [
            'primary_color' => $this->input('primary_color'),
            'secondary_color' => $this->input('secondary_color'),
            'accent_color' => $this->input('accent_color'),
            'text_color' => $this->input('text_color'),
            'background_color' => $this->input('background_color'),
        ];

        if ($this->tenantModel->updateColors($tenant->id, $colors)) {
            Session::success('تم تحديث الألوان بنجاح');
        } else {
            Session::error('حدث خطأ أثناء تحديث الألوان');
        }

        $this->redirect('/dashboard/settings');
    }

    /**
     * تحديث الشعار
     */
    public function updateLogo()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        if (!isset($_FILES['logo']) || $_FILES['logo']['error'] !== UPLOAD_ERR_OK) {
            Session::error('يرجى اختيار صورة');
            $this->redirect('/dashboard/settings');
        }

        $result = $this->uploadFile($_FILES['logo'], $tenant->id, ALLOWED_IMAGE_TYPES);

        if (isset($result['error'])) {
            Session::error($result['error']);
            $this->redirect('/dashboard/settings');
        }

        // حذف الشعار القديم
        if ($tenant->logo) {
            $this->deleteFile($tenant->logo);
        }

        $this->tenantModel->updateLogo($tenant->id, $result['path']);

        Session::success('تم تحديث الشعار بنجاح');
        $this->redirect('/dashboard/settings');
    }

    /**
     * تغيير الثيم
     */
    public function changeTheme()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $themeSlug = $this->input('theme_slug');

        if (empty($themeSlug)) {
            Session::error(lang('theme_error'));
            $this->redirect('/dashboard/themes');
        }

        if ($this->tenantModel->update($tenant->id, ['theme_slug' => $themeSlug])) {
            Session::success(lang('theme_changed'));
        } else {
            Session::error(lang('theme_error'));
        }

        $this->redirect('/dashboard/themes');
    }

    /**
     * عرض صفحة اختيار الثيمات
     */
    public function themes()
    {
        $tenant = Auth::tenant();
        $themeModel = $this->model('Theme');
        $themes = $themeModel->getActive();

        $this->view('dashboard/themes-selection', [
            'title' => lang('choose_theme'),
            'tenant' => $tenant,
            'themes' => $themes
        ]);
    }

    /**
     * نشر الموقع
     */
    public function publish()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        if ($this->tenantModel->update($tenant->id, ['site_status' => 'published'])) {
            Session::success('تم نشر الموقع بنجاح');
        } else {
            Session::error('حدث خطأ أثناء نشر الموقع');
        }

        $this->redirect('/dashboard');
    }

    // ==================== الخدمات ====================

    /**
     * عرض قائمة الخدمات
     */
    public function services()
    {
        $tenant = Auth::tenant();
        $services = $this->serviceModel->getTenantServices($tenant->id);

        $this->view('dashboard/services', [
            'title' => 'الخدمات',
            'tenant' => $tenant,
            'services' => $services
        ]);
    }

    /**
     * عرض نموذج إضافة خدمة
     */
    public function addService()
    {
        $tenant = Auth::tenant();

        $this->view('dashboard/service-form', [
            'title' => 'إضافة خدمة جديدة',
            'tenant' => $tenant,
            'service' => null
        ]);
    }

    /**
     * حفظ خدمة جديدة
     */
    public function storeService()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        $data = [
            'tenant_id' => $tenant->id,
            'title' => $this->input('title'),
            'description' => $this->input('description'),
            'content' => $this->input('content'),
            'icon' => $this->input('icon'),
            'price' => $this->input('price') ?: null,
            'price_text' => $this->input('price_text'),
            'show_on_home' => $this->input('show_on_home') ? 1 : 0,
            'status' => $this->input('status') ?: 'active'
        ];

        // رفع الصورة
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $result = $this->uploadFile($_FILES['image'], $tenant->id . '/services', ALLOWED_IMAGE_TYPES);
            if (!isset($result['error'])) {
                $data['image'] = $result['path'];
            }
        }

        if ($this->serviceModel->createService($data)) {
            Session::success('تم إضافة الخدمة بنجاح');
            $this->redirect('/dashboard/services');
        }

        Session::error('حدث خطأ أثناء إضافة الخدمة');
        $this->redirect('/dashboard/services/add');
    }

    /**
     * عرض نموذج تعديل خدمة
     */
    public function editService($id)
    {
        $tenant = Auth::tenant();
        $service = $this->serviceModel->find($id);

        if (!$service || $service->tenant_id != $tenant->id) {
            Session::error('الخدمة غير موجودة');
            $this->redirect('/dashboard/services');
        }

        $this->view('dashboard/service-form', [
            'title' => 'تعديل الخدمة',
            'tenant' => $tenant,
            'service' => $service
        ]);
    }

    /**
     * تحديث خدمة
     */
    public function updateService($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $service = $this->serviceModel->find($id);

        if (!$service || $service->tenant_id != $tenant->id) {
            Session::error('الخدمة غير موجودة');
            $this->redirect('/dashboard/services');
        }

        $data = [
            'title' => $this->input('title'),
            'description' => $this->input('description'),
            'content' => $this->input('content'),
            'icon' => $this->input('icon'),
            'price' => $this->input('price') ?: null,
            'price_text' => $this->input('price_text'),
            'show_on_home' => $this->input('show_on_home') ? 1 : 0,
            'status' => $this->input('status') ?: 'active'
        ];

        // رفع صورة جديدة
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $result = $this->uploadFile($_FILES['image'], $tenant->id . '/services', ALLOWED_IMAGE_TYPES);
            if (!isset($result['error'])) {
                // حذف الصورة القديمة
                if ($service->image) {
                    $this->deleteFile($service->image);
                }
                $data['image'] = $result['path'];
            }
        }

        if ($this->serviceModel->updateService($id, $data)) {
            Session::success('تم تحديث الخدمة بنجاح');
        } else {
            Session::error('حدث خطأ أثناء تحديث الخدمة');
        }

        $this->redirect('/dashboard/services');
    }

    /**
     * حذف خدمة
     */
    public function deleteService($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $service = $this->serviceModel->find($id);

        if (!$service || $service->tenant_id != $tenant->id) {
            $this->jsonError('الخدمة غير موجودة', [], 404);
        }

        // حذف الصورة
        if ($service->image) {
            $this->deleteFile($service->image);
        }

        if ($this->serviceModel->delete($id)) {
            $this->jsonSuccess([], 'تم حذف الخدمة بنجاح');
        }

        $this->jsonError('حدث خطأ أثناء حذف الخدمة');
    }

    // ==================== البانرات ====================

    /**
     * عرض قائمة البانرات
     */
    public function banners()
    {
        $tenant = Auth::tenant();
        $banners = $this->bannerModel->getTenantBanners($tenant->id);

        $this->view('dashboard/banners', [
            'title' => 'البانرات',
            'tenant' => $tenant,
            'banners' => $banners
        ]);
    }

    /**
     * إضافة بانر جديد
     */
    public function storeBanner()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            Session::error('يرجى اختيار صورة');
            $this->redirect('/dashboard/banners');
        }

        $result = $this->uploadFile($_FILES['image'], $tenant->id . '/banners', ALLOWED_IMAGE_TYPES);

        if (isset($result['error'])) {
            Session::error($result['error']);
            $this->redirect('/dashboard/banners');
        }

        $data = [
            'tenant_id' => $tenant->id,
            'title' => $this->input('title'),
            'subtitle' => $this->input('subtitle'),
            'description' => $this->input('description'),
            'image' => $result['path'],
            'link' => $this->input('link'),
            'button_text' => $this->input('button_text'),
            'position' => $this->input('position') ?: 'hero',
            'status' => 'active'
        ];

        if ($this->bannerModel->createBanner($data)) {
            Session::success('تم إضافة البانر بنجاح');
        } else {
            Session::error('حدث خطأ أثناء إضافة البانر');
        }

        $this->redirect('/dashboard/banners');
    }

    /**
     * حذف بانر
     */
    public function deleteBanner($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        $banner = $this->bannerModel->find($id);

        if (!$banner || $banner->tenant_id != $tenant->id) {
            $this->jsonError('البانر غير موجود', [], 404);
        }

        if ($this->bannerModel->deleteWithImage($id)) {
            $this->jsonSuccess([], 'تم حذف البانر بنجاح');
        }

        $this->jsonError('حدث خطأ أثناء حذف البانر');
    }

    // ==================== المعرض ====================

    /**
     * عرض المعرض
     */
    public function gallery()
    {
        $tenant = Auth::tenant();
        $gallery = $this->galleryModel->getTenantGallery($tenant->id);
        $categories = $this->galleryModel->getCategories($tenant->id);

        $this->view('dashboard/gallery', [
            'title' => 'معرض الصور',
            'tenant' => $tenant,
            'gallery' => $gallery,
            'categories' => $categories
        ]);
    }

    /**
     * رفع صور للمعرض
     */
    public function uploadGallery()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        if (!isset($_FILES['images'])) {
            $this->jsonError('لم يتم اختيار صور');
        }

        $uploaded = $this->galleryModel->uploadMultiple(
            $tenant->id,
            $_FILES['images'],
            $this->input('category')
        );

        if (count($uploaded) > 0) {
            $this->jsonSuccess(['count' => count($uploaded)], 'تم رفع ' . count($uploaded) . ' صور بنجاح');
        }

        $this->jsonError('فشل في رفع الصور');
    }

    /**
     * حذف صورة من المعرض
     */
    public function deleteGalleryImage($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $image = $this->galleryModel->find($id);

        if (!$image || $image->tenant_id != $tenant->id) {
            $this->jsonError('الصورة غير موجودة', [], 404);
        }

        if ($this->galleryModel->deleteWithFile($id)) {
            $this->jsonSuccess([], 'تم حذف الصورة بنجاح');
        }

        $this->jsonError('حدث خطأ أثناء حذف الصورة');
    }

    // ==================== آراء العملاء ====================

    /**
     * عرض قائمة الآراء
     */
    public function testimonials()
    {
        $tenant = Auth::tenant();
        $testimonials = $this->testimonialModel->getTenantTestimonials($tenant->id);

        $this->view('dashboard/testimonials', [
            'title' => 'آراء العملاء',
            'tenant' => $tenant,
            'testimonials' => $testimonials
        ]);
    }

    /**
     * إضافة رأي جديد
     */
    public function storeTestimonial()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        $data = [
            'tenant_id' => $tenant->id,
            'client_name' => $this->input('client_name'),
            'client_title' => $this->input('client_title'),
            'content' => $this->input('content'),
            'rating' => $this->input('rating') ?: 5,
            'show_on_home' => $this->input('show_on_home') ? 1 : 0,
            'status' => 'active'
        ];

        // رفع صورة العميل
        if (isset($_FILES['client_image']) && $_FILES['client_image']['error'] === UPLOAD_ERR_OK) {
            $result = $this->uploadFile($_FILES['client_image'], $tenant->id . '/testimonials', ALLOWED_IMAGE_TYPES);
            if (!isset($result['error'])) {
                $data['client_image'] = $result['path'];
            }
        }

        if ($this->testimonialModel->createTestimonial($data)) {
            Session::success('تم إضافة الرأي بنجاح');
        } else {
            Session::error('حدث خطأ أثناء إضافة الرأي');
        }

        $this->redirect('/dashboard/testimonials');
    }

    /**
     * حذف رأي
     */
    public function deleteTestimonial($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        $testimonial = $this->testimonialModel->find($id);

        if (!$testimonial || $testimonial->tenant_id != $tenant->id) {
            $this->jsonError('الرأي غير موجود', [], 404);
        }

        if ($this->testimonialModel->deleteWithImage($id)) {
            $this->jsonSuccess([], 'تم حذف الرأي بنجاح');
        }

        $this->jsonError('حدث خطأ أثناء حذف الرأي');
    }

    // ==================== الرسائل ====================

    /**
     * عرض الرسائل
     */
    public function messages()
    {
        $tenant = Auth::tenant();

        $db = Database::getInstance();
        $messages = $db->query(
            "SELECT * FROM contact_messages WHERE tenant_id = ? ORDER BY created_at DESC",
            [$tenant->id]
        )->results();

        $this->view('dashboard/messages', [
            'title' => 'الرسائل',
            'tenant' => $tenant,
            'messages' => $messages
        ]);
    }

    /**
     * تحديد رسالة كمقروءة
     */
    public function markMessageRead($id)
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();

        $db = Database::getInstance();
        $db->query(
            "UPDATE contact_messages SET is_read = 1 WHERE id = ? AND tenant_id = ?",
            [$id, $tenant->id]
        );

        $this->jsonSuccess([], 'تم تحديد الرسالة كمقروءة');
    }

    // ==================== الاشتراك ====================

    /**
     * عرض صفحة الاشتراك
     */
    public function subscription()
    {
        $tenant = Auth::tenant();

        // الحصول على إحصائيات الاستخدام
        $stats = (object) [
            'services_count' => $this->serviceModel->countByTenant($tenant->id),
            'gallery_count' => $this->galleryModel->countByTenant($tenant->id),
            'banners_count' => $this->bannerModel->countByTenant($tenant->id),
            'pages_count' => $this->pageModel->countByTenant($tenant->id)
        ];

        $this->view('dashboard/subscription', [
            'title' => lang('subscription'),
            'tenant' => $tenant,
            'stats' => $stats
        ]);
    }

    /**
     * استيراد البيانات التجريبية
     */
    public function importDemo()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        
        // الحصول على الثيم الحالي
        $themeModel = $this->model('Theme');
        $theme = $themeModel->find($tenant->theme_id);
        
        if (!$theme) {
            Session::error('القالب غير موجود');
            $this->redirect('/dashboard/settings');
        }

        // استيراد البيانات التجريبية
        if ($this->demoDataModel->reimportForTenant($tenant->id, $theme->slug)) {
            Session::success('تم استيراد البيانات التجريبية بنجاح');
        } else {
            Session::error('حدث خطأ أثناء استيراد البيانات');
        }

        $this->redirect('/dashboard/settings');
    }

    /**
     * تحديث إعدادات الأقسام
     */
    public function updateSections()
    {
        $this->verifyCsrf();

        $tenant = Auth::tenant();
        
        $sections = $this->input('sections', []);
        
        if ($this->tenantModel->updateSectionsConfig($tenant->id, $sections)) {
            Session::success('تم تحديث إعدادات الأقسام بنجاح');
        } else {
            Session::error('حدث خطأ أثناء تحديث الإعدادات');
        }

        $this->redirect('/dashboard/settings');
    }
}
