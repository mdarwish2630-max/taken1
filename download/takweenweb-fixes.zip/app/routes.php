<?php
/**
 * CMS Platform - Routes
 * تعريف المسارات
 */

// ==================== الصفحات الرئيسية ====================
Router::get('/', 'SiteController@index');

// ==================== تغيير اللغة ====================
Router::get('/lang/{lang}', 'LanguageController@change');
Router::get('/lang/current', 'LanguageController@current');
Router::post('/dashboard/settings/language', 'LanguageController@changeSiteLanguage');

// ==================== المصادقة ====================
Router::get('/login', 'AuthController@login');
Router::post('/login', 'AuthController@doLogin');
Router::get('/register', 'AuthController@register');
Router::post('/register', 'AuthController@doRegister');
Router::get('/logout', 'AuthController@logout');
Router::get('/forgot-password', 'AuthController@forgotPassword');
Router::post('/forgot-password', 'AuthController@sendResetLink');
Router::get('/reset-password/{token}', 'AuthController@resetPassword');
Router::post('/reset-password', 'AuthController@updatePassword');

// مسارات بديلة للتوافق
Router::get('/auth/login', 'AuthController@login');
Router::get('/auth/register', 'AuthController@register');
Router::get('/auth/logout', 'AuthController@logout');

// ==================== إنشاء موقع جديد ====================
Router::group(['middleware' => 'auth'], function() {
    Router::get('/site/create', 'SiteCreateController@index');
    Router::post('/site/create', 'SiteCreateController@store');
});

// ==================== عرض مواقع المستأجرين مع /site/ ====================
Router::get('/site/{slug}', 'SiteController@show');
Router::post('/site/{slug}/contact', 'SiteController@contact');
Router::get('/site/{slug}/service/{serviceSlug}', 'SiteController@service');
Router::get('/site/{slug}/services', 'SiteController@services');
Router::get('/site/{slug}/gallery', 'SiteController@gallery');
Router::get('/site/{slug}/contact', 'SiteController@contactPage');
Router::get('/site/{slug}/about', 'SiteController@about');

// ==================== لوحة تحكم العميل ====================
Router::group(['middleware' => 'customer'], function() {
    // الرئيسية
    Router::get('/dashboard', 'DashboardController@index');
    
    // الإعدادات
    Router::get('/dashboard/settings', 'DashboardController@settings');
    Router::post('/dashboard/settings', 'DashboardController@updateSettings');
    Router::post('/dashboard/settings/colors', 'DashboardController@updateColors');
    Router::post('/dashboard/settings/logo', 'DashboardController@updateLogo');
    Router::post('/dashboard/settings/theme', 'DashboardController@changeTheme');
    Router::post('/dashboard/settings/import-demo', 'DashboardController@importDemo');
    Router::post('/dashboard/settings/sections', 'DashboardController@updateSections');
    Router::get('/dashboard/themes', 'DashboardController@themes');
    Router::get('/dashboard/subscription', 'DashboardController@subscription');
    Router::get('/dashboard/publish', 'DashboardController@publish');
    
    // الخدمات
    Router::get('/dashboard/services', 'DashboardController@services');
    Router::get('/dashboard/services/add', 'DashboardController@addService');
    Router::post('/dashboard/services/add', 'DashboardController@storeService');
    Router::get('/dashboard/services/edit/{id}', 'DashboardController@editService');
    Router::post('/dashboard/services/edit/{id}', 'DashboardController@updateService');
    Router::post('/dashboard/services/delete/{id}', 'DashboardController@deleteService');
    
    // البانرات
    Router::get('/dashboard/banners', 'DashboardController@banners');
    Router::post('/dashboard/banners', 'DashboardController@storeBanner');
    Router::post('/dashboard/banners/delete/{id}', 'DashboardController@deleteBanner');
    
    // المعرض
    Router::get('/dashboard/gallery', 'DashboardController@gallery');
    Router::post('/dashboard/gallery', 'DashboardController@uploadGallery');
    Router::post('/dashboard/gallery/delete/{id}', 'DashboardController@deleteGalleryImage');
    
    // آراء العملاء
    Router::get('/dashboard/testimonials', 'DashboardController@testimonials');
    Router::post('/dashboard/testimonials', 'DashboardController@storeTestimonial');
    Router::post('/dashboard/testimonials/delete/{id}', 'DashboardController@deleteTestimonial');
    
    // الرسائل
    Router::get('/dashboard/messages', 'DashboardController@messages');
    Router::post('/dashboard/messages/read/{id}', 'DashboardController@markMessageRead');
    
    // الصفحات
    Router::get('/dashboard/pages', 'PageController@index');
    Router::get('/dashboard/pages/add', 'PageController@add');
    Router::post('/dashboard/pages/add', 'PageController@store');
    Router::get('/dashboard/pages/edit/{id}', 'PageController@edit');
    Router::post('/dashboard/pages/edit/{id}', 'PageController@update');
    Router::post('/dashboard/pages/delete/{id}', 'PageController@delete');

    // Blog
    Router::get('/dashboard/blog', 'BlogController@index');
    Router::get('/dashboard/blog/add', 'BlogController@add');
    Router::post('/dashboard/blog/add', 'BlogController@store');
    Router::get('/dashboard/blog/edit/{id}', 'BlogController@edit');
    Router::post('/dashboard/blog/edit/{id}', 'BlogController@update');
    Router::post('/dashboard/blog/delete/{id}', 'BlogController@delete');
    Router::get('/dashboard/blog/show/{id}', 'BlogController@show');

    // SEO
    Router::get('/dashboard/seo', 'SeoController@index');
    Router::post('/dashboard/seo', 'SeoController@update');
    Router::get('/dashboard/seo/sitemap', 'SeoController@generateSitemap');
    Router::post('/dashboard/seo/robots', 'SeoController@updateRobots');

    // Analytics
    Router::get('/dashboard/analytics', 'AnalyticsController@index');

    // Theme
    Router::get('/dashboard/theme', 'ThemeController@index');
    Router::post('/dashboard/theme', 'ThemeController@update');
    Router::post('/dashboard/theme/reset', 'ThemeController@reset');

    // Subscription
    Router::get('/dashboard/subscription-plans', 'SubscriptionController@plans');
    Router::post('/dashboard/subscription/plans/{id}', 'SubscriptionController@selectPlan');
    Router::get('/dashboard/subscription/payment', 'SubscriptionController@payment');
    Router::post('/dashboard/subscription/payment', 'SubscriptionController@processPayment');
    Router::get('/dashboard/subscription/renew', 'SubscriptionController@renew');
    Router::post('/dashboard/subscription/cancel', 'SubscriptionController@cancel');
    Router::get('/dashboard/subscription/upgrade', 'SubscriptionController@upgrade');
    Router::get('/dashboard/invoices', 'SubscriptionController@invoices');

    // Domains
    Router::get('/dashboard/domains', 'DomainController@index');
    Router::post('/dashboard/domains/subdomain', 'DomainController@updateSubdomain');
    Router::post('/dashboard/domains/custom', 'DomainController@addCustomDomain');
    Router::post('/dashboard/domains/verify', 'DomainController@verifyDomain');
    Router::post('/dashboard/domains/remove', 'DomainController@removeCustomDomain');

    // Forms
    Router::get('/dashboard/forms', 'FormController@index');
    Router::get('/dashboard/forms/add', 'FormController@add');
    Router::post('/dashboard/forms/add', 'FormController@store');
    Router::get('/dashboard/forms/edit/{id}', 'FormController@edit');
    Router::post('/dashboard/forms/edit/{id}', 'FormController@update');
    Router::post('/dashboard/forms/delete/{id}', 'FormController@delete');
    Router::get('/dashboard/forms/submissions/{id}', 'FormController@submissions');
});

// ==================== لوحة تحكم المدير ====================
Router::group(['middleware' => 'admin'], function() {
    Router::get('/admin', 'AdminController@index');
    Router::get('/admin/users', 'AdminController@users');
    Router::get('/admin/sites', 'AdminController@sites');
    Router::get('/admin/sites/view/{id}', 'AdminController@viewSite');
    Router::post('/admin/sites/status', 'AdminController@changeSubscriptionStatus');
    Router::get('/admin/sites/renew/{id}', 'AdminController@renewSubscription');
    Router::get('/admin/settings', 'AdminController@settings');
    Router::post('/admin/settings', 'AdminController@updateSettings');
    Router::get('/admin/analytics', 'AdminController@analytics');
    
    // إدارة الخطط
    Router::get('/admin/plans', 'AdminController@plans');
    Router::get('/admin/plans/add', 'AdminController@addPlan');
    Router::post('/admin/plans/add', 'AdminController@storePlan');
    Router::get('/admin/plans/edit/{id}', 'AdminController@editPlan');
    Router::post('/admin/plans/edit/{id}', 'AdminController@updatePlan');
    Router::post('/admin/plans/delete/{id}', 'AdminController@deletePlan');
    
    // إدارة إعدادات الموقع الرئيسي
    Router::get('/admin/site-settings', 'AdminController@siteSettings');
    Router::post('/admin/site-settings', 'AdminController@updateSiteSettings');
    Router::post('/admin/site-settings/logo', 'AdminController@updateSiteLogo');
    Router::post('/admin/site-settings/hero-image', 'AdminController@updateHeroImage');
    
    // إدارة شهادات الموقع الرئيسي
    Router::get('/admin/site-testimonials', 'AdminController@siteTestimonials');
    Router::post('/admin/site-testimonials', 'AdminController@storeSiteTestimonial');
    Router::post('/admin/site-testimonials/delete/{id}', 'AdminController@deleteSiteTestimonial');
    
    // إدارة مميزات الموقع الرئيسي
    Router::get('/admin/site-features', 'AdminController@siteFeatures');
    Router::post('/admin/site-features', 'AdminController@storeSiteFeature');
    Router::post('/admin/site-features/delete/{id}', 'AdminController@deleteSiteFeature');
    
    // إدارة الاشتراكات
    Router::get('/admin/subscriptions', 'AdminController@subscriptions');
});

// ==================== عرض مواقع المستأجرين (المسارات المختصرة - يجب أن تكون الأخيرة) ====================
Router::get('/{slug}', 'SiteController@show');
Router::post('/{slug}/contact', 'SiteController@contact');
Router::get('/{slug}/service/{serviceSlug}', 'SiteController@service');
Router::get('/{slug}/services', 'SiteController@services');
Router::get('/{slug}/gallery', 'SiteController@gallery');
Router::get('/{slug}/contact', 'SiteController@contactPage');
Router::get('/{slug}/about', 'SiteController@about');
