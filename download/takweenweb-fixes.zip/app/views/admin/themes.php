<?php
/**
 * Admin Themes View
 * إدارة القوالب
 */

$dir = Language::direction();
$this->setLayout('admin');
?>

<div class="page-header">
    <h1 class="page-title">
        <i class="fas fa-palette"></i>
        <?= lang('themes') ?? 'القوالب' ?>
    </h1>
</div>

<!-- Themes Grid -->
<div class="themes-admin-grid">
    <?php if (!empty($dir_themes)): ?>
    <?php foreach ($dir_themes as $theme): ?>
    <div class="theme-admin-card">
        <div class="theme-admin-preview">
            <i class="fas fa-palette"></i>
        </div>
        <div class="theme-admin-info">
            <h3><?= $this->e($theme->name) ?></h3>
            <p><?= $this->e($theme->slug) ?></p>
            <span class="badge badge-success"><?= lang('published') ?? 'مفعّل' ?></span>
        </div>
    </div>
    <?php endforeach; ?>
    <?php else: ?>
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        <?= lang('no_data') ?? 'لا توجد بيانات' ?>
    </div>
    <?php endif; ?>
</div>

<style>
.themes-admin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 1.5rem;
    margin-top: 1.5rem;
}

.theme-admin-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    border: 1px solid var(--border);
}

.theme-admin-preview {
    height: 160px;
    background: linear-gradient(135deg, #4f46e5, #7c3aed);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 3rem;
}

.theme-admin-info {
    padding: 1.25rem;
}

.theme-admin-info h3 {
    font-size: 1.1rem;
    font-weight: 700;
    margin-bottom: 0.25rem;
}

.theme-admin-info p {
    color: var(--text-muted);
    font-size: 0.85rem;
    margin-bottom: 0.75rem;
}
</style>
