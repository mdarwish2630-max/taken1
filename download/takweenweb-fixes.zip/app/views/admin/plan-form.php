<?php
/**
 * Admin - Plan Form
 * نموذج إضافة/تعديل خطة
 */

$this->setLayout('admin');
?>

<div class="page-header">
    <h1 class="page-title">
        <?= isset($plan) ? (lang('edit_plan') ?? 'تعديل الخطة') : (lang('add_plan') ?? 'إضافة خطة جديدة') ?>
    </h1>
</div>

<form method="POST" action="<?= isset($plan) ? url('/admin/plans/edit/' . $plan->id) : url('/admin/plans/add') ?>">
    <?= $this->csrf() ?>
    
    <div class="d-flex gap-3" style="flex-wrap: wrap;">
        <!-- Basic Info -->
        <div class="card" style="flex: 2; min-width: 400px;">
            <div class="card-header">
                <h3 class="card-title"><?= lang('basic_info') ?? 'معلومات أساسية' ?></h3>
            </div>
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label"><?= lang('plan_name') ?? 'اسم الخطة' ?> *</label>
                    <input type="text" name="name" class="form-control" 
                           value="<?= $this->e($plan->name ?? '') ?>" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('slug') ?? 'المعرف' ?></label>
                    <input type="text" name="slug" class="form-control" 
                           value="<?= $this->e($plan->slug ?? '') ?>" 
                           placeholder="مثال: basic, professional, enterprise">
                    <span class="form-hint"><?= lang('slug_hint') ?? 'يستخدم في الروابط والتعريف الفريد' ?></span>
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('description') ?? 'الوصف' ?></label>
                    <textarea name="description" class="form-control" rows="3"><?= $this->e($plan->description ?? '') ?></textarea>
                </div>
                
                <div class="d-flex gap-2">
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label"><?= lang('price') ?? 'السعر' ?> *</label>
                        <input type="number" name="price" class="form-control" 
                               value="<?= $plan->price ?? 0 ?>" step="0.01" min="0" required>
                    </div>
                    
                    <div class="form-group" style="width: 100px;">
                        <label class="form-label"><?= lang('currency') ?? 'العملة' ?></label>
                        <select name="currency" class="form-control">
                            <option value="SAR" <?= ($plan->currency ?? 'SAR') === 'SAR' ? 'selected' : '' ?>>SAR</option>
                            <option value="USD" <?= ($plan->currency ?? '') === 'USD' ? 'selected' : '' ?>>USD</option>
                            <option value="AED" <?= ($plan->currency ?? '') === 'AED' ? 'selected' : '' ?>>AED</option>
                        </select>
                    </div>
                </div>
                
                <div class="d-flex gap-2">
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label"><?= lang('duration_days') ?? 'مدة الاشتراك (أيام)' ?></label>
                        <input type="number" name="duration_days" class="form-control" 
                               value="<?= $plan->duration_days ?? 30 ?>" min="1">
                    </div>
                    
                    <div class="form-group" style="flex: 1;">
                        <label class="form-label"><?= lang('trial_days') ?? 'أيام التجربة المجانية' ?></label>
                        <input type="number" name="trial_days" class="form-control" 
                               value="<?= $plan->trial_days ?? 7 ?>" min="0">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Features & Limits -->
        <div style="flex: 1; min-width: 300px;">
            <!-- Features -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?= lang('features') ?? 'الميزات' ?></h3>
                </div>
                <div class="card-body">
                    <div class="features-list">
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_custom_domain" value="1" 
                                       <?= ($plan->has_custom_domain ?? 0) ? 'checked' : '' ?>>
                                <span><?= lang('custom_domain') ?? 'دومين مخصص' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_ssl" value="1" 
                                       <?= ($plan->has_ssl ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('ssl_certificate') ?? 'شهادة SSL' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_analytics" value="1" 
                                       <?= ($plan->has_analytics ?? 0) ? 'checked' : '' ?>>
                                <span><?= lang('analytics') ?? 'إحصائيات متقدمة' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_custom_colors" value="1" 
                                       <?= ($plan->has_custom_colors ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('custom_colors') ?? 'ألوان مخصصة' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_gallery" value="1" 
                                       <?= ($plan->has_gallery ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('gallery') ?? 'معرض الصور' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_testimonials" value="1" 
                                       <?= ($plan->has_testimonials ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('testimonials') ?? 'آراء العملاء' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_banners" value="1" 
                                       <?= ($plan->has_banners ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('banners') ?? 'بانرات' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_blog" value="1" 
                                       <?= ($plan->has_blog ?? 0) ? 'checked' : '' ?>>
                                <span><?= lang('blog') ?? 'مدونة' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_forms" value="1" 
                                       <?= ($plan->has_forms ?? 0) ? 'checked' : '' ?>>
                                <span><?= lang('custom_forms') ?? 'نماذج مخصصة' ?></span>
                            </label>
                        </div>
                        
                        <div class="feature-item">
                            <label class="checkbox-label">
                                <input type="checkbox" name="has_seo" value="1" 
                                       <?= ($plan->has_seo ?? 1) ? 'checked' : '' ?>>
                                <span><?= lang('seo_settings') ?? 'إعدادات SEO' ?></span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Status -->
            <div class="card mt-3">
                <div class="card-header">
                    <h3 class="card-title"><?= lang('status_settings') ?? 'إعدادات الحالة' ?></h3>
                </div>
                <div class="card-body">
                    <div class="feature-item">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_active" value="1" 
                                   <?= ($plan->is_active ?? 1) ? 'checked' : '' ?>>
                            <span><?= lang('active') ?? 'نشط' ?></span>
                        </label>
                    </div>
                    
                    <div class="feature-item">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_free" value="1" 
                                   <?= ($plan->is_free ?? 0) ? 'checked' : '' ?>>
                            <span><?= lang('free_plan') ?? 'خطة مجانية' ?></span>
                        </label>
                    </div>
                    
                    <div class="feature-item">
                        <label class="checkbox-label">
                            <input type="checkbox" name="is_popular" value="1" 
                                   <?= ($plan->is_popular ?? 0) ? 'checked' : '' ?>>
                            <span><?= lang('popular') ?? 'الأكثر شعبية' ?></span>
                        </label>
                    </div>
                    
                    <div class="form-group mt-2">
                        <label class="form-label"><?= lang('sort_order') ?? 'ترتيب العرض' ?></label>
                        <input type="number" name="sort_order" class="form-control" 
                               value="<?= $plan->sort_order ?? 0 ?>" min="0">
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Limits -->
    <div class="card mt-3">
        <div class="card-header">
            <h3 class="card-title"><?= lang('limits') ?? 'الحدود والقيود' ?></h3>
        </div>
        <div class="card-body">
            <p style="color: #64748b; margin-bottom: 1rem;">
                <?= lang('limits_hint') ?? 'استخدم -1 للقيمة غير المحدودة' ?>
            </p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem;">
                <div class="form-group">
                    <label class="form-label"><?= lang('max_services') ?? 'الحد الأقصى للخدمات' ?></label>
                    <input type="number" name="max_services" class="form-control" 
                           value="<?= $plan->max_services ?? 10 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('max_gallery_images') ?? 'الحد الأقصى للصور' ?></label>
                    <input type="number" name="max_gallery_images" class="form-control" 
                           value="<?= $plan->max_gallery_images ?? 20 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('max_banners') ?? 'الحد الأقصى للبانرات' ?></label>
                    <input type="number" name="max_banners" class="form-control" 
                           value="<?= $plan->max_banners ?? 3 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('max_pages') ?? 'الحد الأقصى للصفحات' ?></label>
                    <input type="number" name="max_pages" class="form-control" 
                           value="<?= $plan->max_pages ?? 10 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('max_testimonials') ?? 'الحد الأقصى للآراء' ?></label>
                    <input type="number" name="max_testimonials" class="form-control" 
                           value="<?= $plan->max_testimonials ?? 10 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('max_forms') ?? 'الحد الأقصى للنماذج' ?></label>
                    <input type="number" name="max_forms" class="form-control" 
                           value="<?= $plan->max_forms ?? 0 ?>">
                </div>
                
                <div class="form-group">
                    <label class="form-label"><?= lang('storage_limit_mb') ?? 'مساحة التخزين (MB)' ?></label>
                    <input type="number" name="storage_limit_mb" class="form-control" 
                           value="<?= $plan->storage_limit_mb ?? 100 ?>">
                </div>
            </div>
        </div>
    </div>
    
    <div class="mt-3">
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-save"></i>
            <?= lang('save') ?? 'حفظ' ?>
        </button>
        <a href="<?= url('/admin/plans') ?>" class="btn btn-outline">
            <?= lang('cancel') ?? 'إلغاء' ?>
        </a>
    </div>
</form>

<style>
.features-list {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.feature-item {
    padding: 0.5rem;
    background: var(--light);
    border-radius: var(--radius);
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    cursor: pointer;
}

.checkbox-label input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
}
</style>
