<?php
/**
 * Admin - Subscription Plans Management
 * إدارة خطط الاشتراك
 */

$this->setLayout('admin');
?>

<div class="page-header">
    <h1 class="page-title"><?= lang('subscription_plans') ?? 'خطط الاشتراك' ?></h1>
    <div class="header-actions">
        <a href="<?= url('/admin/plans/add') ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i>
            <?= lang('add_plan') ?? 'إضافة خطة جديدة' ?>
        </a>
    </div>
</div>

<?php if (Session::has('success')): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i>
    <?= Session::getSuccess() ?>
</div>
<?php endif; ?>

<?php if (Session::has('error')): ?>
<div class="alert alert-danger">
    <i class="fas fa-exclamation-circle"></i>
    <?= Session::getError() ?>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th><?= lang('plan_name') ?? 'اسم الخطة' ?></th>
                        <th><?= lang('price') ?? 'السعر' ?></th>
                        <th><?= lang('duration') ?? 'المدة' ?></th>
                        <th><?= lang('trial_days') ?? 'أيام التجربة' ?></th>
                        <th><?= lang('custom_domain') ?? 'دومين مخصص' ?></th>
                        <th><?= lang('subscribers') ?? 'المشتركين' ?></th>
                        <th><?= lang('status') ?? 'الحالة' ?></th>
                        <th><?= lang('actions') ?? 'الإجراءات' ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($plans as $plan): ?>
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <?php if ($plan->is_popular): ?>
                                <span class="badge badge-warning" style="font-size: 0.7rem;">
                                    <i class="fas fa-star"></i>
                                </span>
                                <?php endif; ?>
                                <div>
                                    <strong><?= $plan->name ?></strong>
                                    <div style="font-size: 0.75rem; color: #64748b;"><?= $plan->slug ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <strong style="color: var(--primary);">
                                <?= number_format($plan->price, 0) ?> <?= $plan->currency ?>
                            </strong>
                        </td>
                        <td><?= $plan->duration_days ?> <?= lang('days') ?? 'يوم' ?></td>
                        <td>
                            <?php if ($plan->trial_days > 0): ?>
                            <span class="badge badge-success"><?= $plan->trial_days ?> <?= lang('days') ?? 'يوم' ?></span>
                            <?php else: ?>
                            <span style="color: #94a3b8;">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($plan->has_custom_domain): ?>
                            <span class="badge badge-success"><i class="fas fa-check"></i></span>
                            <?php else: ?>
                            <span class="badge badge-secondary"><i class="fas fa-times"></i></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge badge-info"><?= $plan->subscribers_count ?? 0 ?></span>
                        </td>
                        <td>
                            <?php if ($plan->is_active): ?>
                            <span class="badge badge-success"><?= lang('active') ?? 'نشط' ?></span>
                            <?php else: ?>
                            <span class="badge badge-danger"><?= lang('inactive') ?? 'غير نشط' ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div style="display: flex; gap: 0.5rem;">
                                <a href="<?= url('/admin/plans/edit/' . $plan->id) ?>" 
                                   class="btn btn-sm btn-outline" title="<?= lang('edit') ?? 'تعديل' ?>">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if (!($plan->subscribers_count > 0)): ?>
                                <form method="POST" action="<?= url('/admin/plans/delete/' . $plan->id) ?>" 
                                      style="display: inline;" 
                                      onsubmit="return confirm('<?= lang('confirm_delete') ?? 'هل أنت متأكد من الحذف؟' ?>');">
                                    <?= $this->csrf() ?>
                                    <button type="submit" class="btn btn-sm btn-danger" title="<?= lang('delete') ?? 'حذف' ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if (empty($plans)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 2rem; color: #64748b;">
                            <i class="fas fa-inbox" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                            <?= lang('no_plans') ?? 'لا توجد خطط. أضف خطة جديدة للبدء.' ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Plans Comparison -->
<div class="card mt-3">
    <div class="card-header">
        <h3 class="card-title"><?= lang('plans_comparison') ?? 'مقارنة الخطط' ?></h3>
    </div>
    <div class="card-body" style="overflow-x: auto;">
        <table class="table" style="min-width: 800px;">
            <thead>
                <tr>
                    <th><?= lang('feature') ?? 'الميزة' ?></th>
                    <?php foreach ($plans as $plan): ?>
                    <th style="text-align: center;"><?= $plan->name ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= lang('custom_domain') ?? 'دومين مخصص' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->has_custom_domain ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>' ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('ssl_certificate') ?? 'شهادة SSL' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->has_ssl ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>' ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('analytics') ?? 'الإحصائيات' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->has_analytics ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>' ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('blog') ?? 'المدونة' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->has_blog ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>' ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('custom_forms') ?? 'نماذج مخصصة' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->has_forms ? '<i class="fas fa-check" style="color: #10b981;"></i>' : '<i class="fas fa-times" style="color: #ef4444;"></i>' ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('max_services') ?? 'الحد الأقصى للخدمات' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;">
                        <?= $plan->max_services == -1 ? '<span style="color: #10b981;">∞</span>' : $plan->max_services ?>
                    </td>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <td><?= lang('storage_limit') ?? 'مساحة التخزين' ?></td>
                    <?php foreach ($plans as $plan): ?>
                    <td style="text-align: center;"><?= $plan->storage_limit_mb ?> MB</td>
                    <?php endforeach; ?>
                </tr>
            </tbody>
        </table>
    </div>
</div>
